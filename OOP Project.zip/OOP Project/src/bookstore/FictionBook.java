/*package bookstore;

public class FictionBook {
    public FictionBook(String title, String author, String isbn, double price) {
        super(title, author, isbn, price, "Fiction");
    }
}
*/
package bookstore;

public class FictionBook extends Book {
    public FictionBook(String title, String author, String isbn, double price) {
        super(title, author, isbn, price);
    }

    @Override
    public String getType() {
        return "Fiction";
    }
}
