//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
package bookstore;
import utils.InputHelper;

    public class Main {
        public static void main(String[] args) {
            BookStore bookStore = new BookStore();
            int choice;

            do {
                System.out.println("\n--- Book Store Management System ---");
                System.out.println("1. Add a Fiction Book");
                System.out.println("2. Add a Non-Fiction Book");
                System.out.println("3. View All Books");
                System.out.println("4. Search Book by Title");
                System.out.println("5. Delete Book by ISBN");
                System.out.println("6. Exit");

                choice = InputHelper.getIntInput("Enter your choice: ");
                InputHelper.getStringInput(""); // clear buffer

                switch (choice) {
                    case 1:
                        addBook(bookStore, "Fiction");
                        break;

                    case 2:
                        addBook(bookStore, "Non-Fiction");
                        break;

                    case 3:
                        bookStore.viewBooks();
                        break;

                    case 4:
                        String title = InputHelper.getStringInput("Enter title to search: ");
                        bookStore.searchBookByTitle(title);
                        break;

                    case 5:
                        String isbn = InputHelper.getStringInput("Enter ISBN to delete: ");
                        bookStore.deleteBook(isbn);
                        break;

                    case 6:
                        System.out.println("Exiting Book Store Management System. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 6);
        }

        private static void addBook(BookStore bookStore, String type) {
            String title = InputHelper.getStringInput("Enter title: ");
            String author = InputHelper.getStringInput("Enter author: ");
            String isbn = InputHelper.getStringInput("Enter ISBN: ");
            double price = InputHelper.getDoubleInput("Enter price: ");

            Book newBook = type.equals("Fiction")
                    ? new FictionBook(title, author, isbn, price)
                    : new NonFictionBook(title, author, isbn, price);

            bookStore.addBook(newBook);
        }

}