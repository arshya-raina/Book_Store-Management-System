/*package bookstore;
import java.util.ArrayList;
public class BookStore {
    private ArrayList<Book> books;

    public BookStore() {
        books = new ArrayList<>();
        initializeBooks();
    }

    private void initializeBooks() {
        books.add(new FictionBook("To Kill a Mockingbird", "Harper Lee", "9780060935467", 599));
        books.add(new FictionBook("1984", "George Orwell", "9780451524935", 620));
        books.add(new NonFictionBook("Sapiens", "Yuval Noah Harari", "9780062316110", 720));
        books.add(new NonFictionBook("Educated", "Tara Westover", "9780399590504", 850));
    }

    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added successfully!");
    }

    public void viewBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available in the store.");
            return;
        }
        for (Book book : books) {
            book.displayBook();
            System.out.println();
        }
    }

    public void searchBookByTitle(String title) {
        boolean found = false;
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                book.displayBook();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Book with title \"" + title + "\" not found.");
        }
    }

    public void deleteBook(String isbn) {
        boolean removed = books.removeIf(book -> book.getIsbn().equals(isbn));
        if (removed) {
            System.out.println("Book removed successfully!");
        } else {
            System.out.println("Book with ISBN \"" + isbn + "\" not found.");
        }
    }
}
}*/
package bookstore;

import java.util.ArrayList;
import java.util.List;

public class BookStore {
    private List<Book> books = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
        System.out.println(book.getType() + " book added: " + book.getTitle());
    }

    public void viewBooks() {
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor()
                    + ", ISBN: " + book.getIsbn() + ", Price: " + book.getPrice()
                    + ", Type: " + book.getType());
        }
    }

    public void searchBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.println("Found: " + book.getTitle() + " by " + book.getAuthor());
                return;
            }
        }
        System.out.println("Book not found.");
    }

    public void deleteBook(String isbn) {
        books.removeIf(book -> book.getIsbn().equals(isbn));
        System.out.println("Book with ISBN " + isbn + " has been deleted.");
    }
}

