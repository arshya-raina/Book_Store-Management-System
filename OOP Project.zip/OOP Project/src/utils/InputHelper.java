package utils;
import java.util.Scanner;

public class InputHelper {
        private static final Scanner scanner = new Scanner(System.in);

        // Method to get a string input from the user
        public static String getStringInput(String message) {
            System.out.print(message);
            return scanner.nextLine();
        }

        // Method to get a double input from the user
        public static double getDoubleInput(String message) {
            System.out.print(message);
            return scanner.nextDouble();
        }

        // Method to get an integer input from the user
        public static int getIntInput(String message) {
            System.out.print(message);
            return scanner.nextInt();
        }

}
